﻿using System;

namespace txtEmail
{
    internal class Text
    {
        public static explicit operator Text(string v)
        {
            throw new NotImplementedException();
        }
    }
}